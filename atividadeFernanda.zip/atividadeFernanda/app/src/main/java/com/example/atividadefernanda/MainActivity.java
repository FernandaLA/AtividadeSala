package com.example.atividadefernanda;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView vlrConsumo = (TextView)findViewById(R.id.edt_consumo);
        final TextView vlrCouvert = (TextView)findViewById(R.id.edt_couvert_artistico);
        final TextView qtdPessoas = (TextView)findViewById(R.id.edt_dividir);
        final TextView txServico = (TextView)findViewById(R.id.edt_servico);
        final TextView vlrTotal = (TextView)findViewById(R.id.edt_conta_total);
        final TextView vlrPessoa = (TextView)findViewById(R.id.edt_valor_pessoa);

        Button btnCalcular = (Button) findViewById(R.id.bt_calcular);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                double consumo = Double.parseDouble(vlrConsumo.getText().toString());
                double serv = 10/100*consumo;
                txServico.setText(""+serv);
                double couvert = Double.parseDouble(vlrCouvert.getText().toString());
                double total = consumo+couvert+serv;
                vlrTotal.setText(""+total);
                int numPessoa = Integer.parseInt(qtdPessoas.getText().toString());
                double dividido = total/numPessoa;
                vlrPessoa.setText(""+dividido);
            }
        });
    }
}
