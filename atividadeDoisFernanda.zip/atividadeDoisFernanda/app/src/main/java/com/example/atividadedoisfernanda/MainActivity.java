package com.example.atividadedoisfernanda;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Intent itCal = new Intent(this, CalculadoraActivity.class);
        final Intent itNav = new Intent(this, NavegadorActivity.class);

        Button btnCalculadora = (Button) findViewById(R.id.bt_calculadora);
        Button btnNavegador = (Button) findViewById(R.id.bt_navegador);

        btnCalculadora.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(itCal);
            }
        });

        btnNavegador.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(itNav);
            }
        });
    }
}
