package com.example.atividadedoisfernanda;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class CalculadoraActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora);

        final Intent itVol = new Intent(this, MainActivity.class);

        Button btnVoltar = (Button) findViewById(R.id.bt_voltar);
        Button btnSomar = (Button) findViewById(R.id.bt_somar);
        Button btnSubtrair = (Button) findViewById(R.id.bt_subtrair);
        Button btnMult = (Button) findViewById(R.id.bt_multi);
        Button btnDivid = (Button) findViewById(R.id.bt_dividir);
        Button btnPorcent = (Button) findViewById(R.id.bt_porcent);
        final TextView vlrUm = (TextView)findViewById(R.id.vlr_um);
        final TextView vlrDois = (TextView)findViewById(R.id.vlr_dois);
        final TextView vlPUm = (TextView)findViewById(R.id.vl_pUm);
        final TextView vlPDois = (TextView)findViewById(R.id.vl_pDois);
        final TextView vlrResult = (TextView)findViewById(R.id.vlr_resultado);

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(itVol);
            }
        });

        btnSomar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                double v1 = Double.parseDouble(vlrUm.getText().toString());
                double v2 = Double.parseDouble(vlrDois.getText().toString());
                double res = v1+v2;
                vlrResult.setText(""+res);
            }
        });

        btnSubtrair.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                double v1 = Double.parseDouble(vlrUm.getText().toString());
                double v2 = Double.parseDouble(vlrDois.getText().toString());
                double res = v1-v2;
                vlrResult.setText(""+res);
            }
        });

        btnMult.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                double v1 = Double.parseDouble(vlrUm.getText().toString());
                double v2 = Double.parseDouble(vlrDois.getText().toString());
                double res = v1*v2;
                vlrResult.setText(""+res);
            }
        });

        btnDivid.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                double v1 = Double.parseDouble(vlrUm.getText().toString());
                double v2 = Double.parseDouble(vlrDois.getText().toString());
                double res = v1/v2;
                vlrResult.setText(""+res);
            }
        });

        btnPorcent.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                double vp1 = Double.parseDouble(vlPUm.getText().toString());
                double vp2 = Double.parseDouble(vlPDois.getText().toString());
                double res = (vp1/100)*vp2;
                vlrResult.setText(""+res);
            }
        });

    }
}
