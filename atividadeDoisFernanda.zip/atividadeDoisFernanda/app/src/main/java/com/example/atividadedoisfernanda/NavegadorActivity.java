package com.example.atividadedoisfernanda;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

public class NavegadorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navegador);

        final Intent itVol = new Intent(this, MainActivity.class);

        Button btnVoltar = (Button) findViewById(R.id.bt_voltar);
        Button btnIr = (Button) findViewById(R.id.bt_ir);
        final TextView txtUrl = (TextView)findViewById(R.id.txt_url);
        final WebView navWeb = (WebView)findViewById(R.id.nav_web);

        navWeb.loadUrl("https://www.google.com.br");

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(itVol);
            }
        });

        btnIr.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                navWeb.loadUrl(""+txtUrl.getText());
            }
        });
    }
}
